<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\Faculty;
use App\Models\Subject;
use App\Models\SubjectEnrollment;
use Illuminate\Http\Request;

class SubjectEnrollmentController extends Controller
{
    public function index ()
    {
        $departments = Faculty::select('id', 'name')
            ->with('departments:id,name,faculty_id')
            ->orderBy('name')
            ->get();
        $subjects = Subject::selectRaw("`id`, concat(`code`, ' ', `name`) as `name`")
            ->orderBy('name')
            ->get();
        return view('admin.subject-enrollment', compact('departments', 'subjects'));
    }

    public function getAll (Request $request)
    {
        list($sort, $type, $query, $item) = getListItems($request, 'id,created_at');
        $items = SubjectEnrollment::with(['department:id,name','subject:id,name,code'])
            ->select('*','intake as name')
            ->orderBy($sort, $type)
            ->paginate($item);
        return response()->json($items);
    }

    public function submit (Request $request)
    {
        $data = $request->validate([
            'department_id' => 'required|numeric|exists:'.Department::getTableName().',id',
            'subject_id' => 'required|numeric|exists:'.Subject::getTableName().',id',
            'intake_month' => 'required|numeric|min:1|max:12',
            'intake_year' => 'required|numeric|min:2023|max:2030',
            'credit_hour' => 'required|numeric|min:0|max:99',
            'remark' => 'nullable|string|max:500'
        ]);
        $data['intake'] = $data['intake_year'].$data['intake_month'];
        $item = SubjectEnrollment::create($data);
        return response()->json([
            'success' => $item->intake.' as bean created'
        ]);
    }

    public function status (Request $request, $id)
    {
        $data = $request->validate([
            'is_active' => 'required|numeric|in:0,1'
        ]);
        $item = SubjectEnrollment::findOrFail($id);
        $item->update($data);
        return response()->json([
            'success' => $item->intake.' as bean updated'
        ]);
    }

    public function delete ($id)
    {
        $item = SubjectEnrollment::findOrFail($id);
        try{
            $item->delete();
            return response()->json([
                'success' => $item->intake.' as bean deleted'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => $item->intake.' can not be deleted. '.$e->getMessage()
            ]);
        }
    }
}
