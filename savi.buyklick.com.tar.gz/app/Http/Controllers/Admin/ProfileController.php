<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;

class ProfileController extends Controller
{
    /**
     * @return Application|Factory|View
     */
    public function index()
    {
        $user = $this->_getProfile();
        return view('admin.profile', compact('user'));
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function update(Request $request) {
        $values = $request->validate([
            'name' => 'required|string|min:4|max:63'
        ]);
        auth()->user()->update($values);
        return response()->json([
            'success' => 'Profile updated',
            'profile' => $this->_getProfile()
        ]);
    }

    /**
     * @return mixed
     */
    private function _getProfile() {
        return request()->user('web')->only([
            'name', 'email', 'email_verified_at', 'created_at', 'role'
        ]);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function password(Request $request) {
        $request->validate([
            'current_password' => 'required|string|min:6|max:15',
            'password' => 'required|string|min:6|max:15|confirmed|not_in:' . $request->post('current_password')
        ]);
        $user = auth('web')->user();
        if (!Hash::check($request->post('current_password'), $user->password)) {
            return response()->json([
                'message' => 'The given data was invalid',
                'errors' => [
                    'current_password' => ['Current password does not match']
                ]
            ], Response::HTTP_UNPROCESSABLE_ENTITY);
        }
        $user->update(['password' => bcrypt($request->post('password'))]);
        return response()->json(['success' => 'Password has been successfully updated']);
    }
}
