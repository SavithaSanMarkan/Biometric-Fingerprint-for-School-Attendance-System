<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AppSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class AppSettingController extends Controller
{
    public function index() {
        $setting = config('app.settings');
        return view('admin.app-settings', compact('setting'));
    }

    public function update (Request $request) {
        $values = $request->validate([
            'name' => 'required|string|min:2|max:63',
            'mobile' => 'required|string|min:4|max:15',
            'email' => 'required|email|min:4|max:63',
            'phone' => 'nullable|string|min:4|max:50',
            'fax' => 'nullable|string|min:4|max:50',
            'address' => 'nullable|string|min:4|max:191'
        ]);
        foreach ($values as $name => $value) {
            $this->setting($name, $value);
        }
        $app_settings = AppSetting::pluck('value','name')->toArray();
        Cache::put('app_settings', $app_settings);
        return response()->json([
            'success' => 'App setting has been updated',
            'settings' => AppSetting::pluck('value', 'name')->toArray()
        ]);
    }

    private function setting($name, $value = null) {
        return AppSetting::updateOrCreate(['name' => $name], ['value' => $value]);
    }

    public function logo (Request $request) {
        $request->validate([
            'logo' => 'required|file|mimes:jpg,jpeg,png|min:4|max:8192'
        ]);
        $file = $request->file('logo');
        $name = Str::lower('logo_'.uniqid().'.'.$file->getClientOriginalExtension());
        $file->storeAs('public/', $name);
        $logo = AppSetting::where('name', '=', 'logo')->first();
        if ($logo && $logo->value) {
            Storage::disk('public')->delete($logo->value);
        }
        $this->setting('logo', $name);
        $app_settings = AppSetting::pluck('value','name')->toArray();
        Cache::put('app_settings', $app_settings);
        return response()->json([
            'success' => 'Logo has been successfully updated',
            'logo' => $name
        ]);
    }
}
