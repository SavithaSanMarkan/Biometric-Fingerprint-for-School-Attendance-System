<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Faculty;
use Illuminate\Http\Request;

class FacultyController extends Controller
{
    public function index ()
    {
        return view('admin.faculty');
    }

    public function getAll (Request $request)
    {
        list($sort, $type, $query, $item) = getListItems($request, 'id,name,created_at');
        $items = Faculty::when($query, function ($sql) use ($query) {
            $sql->where('name', 'like', "%$query%")
                ->orWhere('description', 'like', "%$query%");
        })
            ->orderBy($sort, $type)
            ->paginate($item);
        return response()->json($items);
    }

    public function submit (Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100|unique:'.Faculty::getTableName(),
            'description' => 'nullable|string|max:500'
        ]);
        $item = Faculty::create($data);
        return response()->json([
            'success' => $item->name.' as bean created'
        ]);
    }

    public function update (Request $request, $id)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100|unique:'.Faculty::getTableName().',name,'.$id,
            'description' => 'nullable|string|max:500'
        ]);
        $item = Faculty::findOrFail($id);
        $item->update($data);
        return response()->json([
            'success' => $item->name.' as bean updated'
        ]);
    }

    public function status (Request $request, $id)
    {
        $data = $request->validate([
            'is_active' => 'required|numeric|in:0,1'
        ]);
        $item = Faculty::findOrFail($id);
        $item->update($data);
        return response()->json([
            'success' => $item->name.' as bean updated'
        ]);
    }

    public function delete ($id)
    {
        $item = Faculty::findOrFail($id);
        try{
            $item->delete();
            return response()->json([
                'success' => $item->name.' as bean deleted'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => $item->name.' can not be deleted. '.$e->getMessage()
            ]);
        }
    }
}
