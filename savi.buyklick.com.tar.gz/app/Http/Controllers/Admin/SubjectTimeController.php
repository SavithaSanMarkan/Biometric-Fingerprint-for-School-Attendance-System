<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Subject;
use App\Models\SubjectEnrollment;
use App\Models\SubjectTime;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SubjectTimeController extends Controller
{
    public function index ()
    {
        $subjects = \DB::table(SubjectEnrollment::getTableName(). ' as e')
            ->join(Subject::getTableName().' as s', 's.id', '=', 'e.subject_id')
            ->selectRaw("`e`.`id`, concat(`s`.`code`, ' ', `s`.`name`, ' (', `e`.`intake`, ')') as `name`")
            ->orderBy('s.name')
            ->orderByDesc('e.intake')
            ->get();
        return view('admin.subject-time', compact('subjects'));
    }

    public function getAll (Request $request)
    {
        list($sort, $type, $query, $item) = getListItems($request, 'id,created_at');
        $items = SubjectTime::with([
            'subject_enrollment' => function ($sql) {
                $sql->with(['subject:id,code,name','department:id,name'])
                    ->select('id', 'subject_id', 'department_id', 'intake');
            }
        ])
            ->orderBy($sort, $type)
            ->paginate($item);
        return response()->json($items);
    }

    public function submit (Request $request)
    {
        $data = $request->validate([
            'subject_enrollment_id' => 'required|numeric|exists:'.SubjectEnrollment::getTableName().',id',
            'timetable' => [
                'required', 'string', 'min:4', 'max:7',
                Rule::unique(SubjectTime::getTableName(), 'timetable')
                    ->where('timetable', $request->post('timetable'))
            ],
        ]);
        $item = SubjectTime::create($data);
        return response()->json([
            'success' => $item->timetable.' as bean created'
        ]);
    }

    public function delete ($id)
    {
        $item = SubjectTime::findOrFail($id);
        try{
            $item->delete();
            return response()->json([
                'success' => $item->timetable.' as bean deleted'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => $item->timetable.' can not be deleted. '.$e->getMessage()
            ]);
        }
    }
}
