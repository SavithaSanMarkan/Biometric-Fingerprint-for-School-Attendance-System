<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Teacher;
use Illuminate\Http\Request;

class TeacherController extends Controller
{
    public function index ()
    {
        return view('admin.teachers');
    }

    public function getAll (Request $request)
    {
        list($sort, $type, $query, $item) = getListItems($request, 'id,name,created_at');
        $items = Teacher::when($query, function ($sql) use ($query) {
            $sql->where('name', 'like', "%$query%")
                ->orWhere('identity', '=', $query)
                ->orWhere('email', '=', $query);
        })
            ->orderBy($sort, $type)
            ->paginate($item);
        return response()->json($items);
    }

    public function submit (Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100',
            'email' => 'required|email|max:63|unique:'.Teacher::getTableName(),
            'identity' => 'required|string|min:2|max:15|unique:'.Teacher::getTableName(),
            'gender' => 'nullable|alpha|in:male,female|max:15',
            'remark' => 'nullable|string|max:500'
        ]);
        $data['password'] = bcrypt('password');
        $item = Teacher::create($data);
        return response()->json([
            'success' => $item->name.' as bean created'
        ]);
    }

    public function update (Request $request, $id)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100',
            'email' => 'required|email|max:63|unique:'.Teacher::getTableName().',email,'.$id,
            'identity' => 'required|string|min:2|max:15|unique:'.Teacher::getTableName().',identity,'.$id,
            'gender' => 'nullable|alpha|in:male,female|max:15',
            'remark' => 'nullable|string|max:500'
        ]);
        $item = Teacher::findOrFail($id);
        $item->update($data);
        return response()->json([
            'success' => $item->name.' as bean updated'
        ]);
    }

    public function status (Request $request, $id)
    {
        $data = $request->validate([
            'is_active' => 'required|numeric|in:0,1'
        ]);
        $item = Teacher::findOrFail($id);
        $item->update($data);
        return response()->json([
            'success' => $item->name.' as bean updated'
        ]);
    }

    public function delete ($id)
    {
        $item = Teacher::findOrFail($id);
        try{
            $item->delete();
            return response()->json([
                'success' => $item->name.' as bean deleted'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => $item->name.' can not be deleted. '.$e->getMessage()
            ]);
        }
    }
}
