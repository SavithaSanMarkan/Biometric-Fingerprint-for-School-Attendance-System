<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\Faculty;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class DepartmentController extends Controller
{
    public function index ()
    {
        $faculties = Faculty::select('id','name')
            ->orderBy('name')
            ->get();
        return view('admin.department', compact('faculties'));
    }

    public function getAll (Request $request)
    {
        list($sort, $type, $query, $item) = getListItems($request, 'id,name,created_at');
        $items = Department::with('faculty:id,name')
            ->when($query, function ($sql) use ($query) {
                $sql->where('name', 'like', "%$query%")
                    ->orWhere('description', 'like', "%$query%");
            })
            ->orderBy($sort, $type)
            ->paginate($item);
        return response()->json($items);
    }

    public function submit (Request $request)
    {
        $data = $request->validate([
            'name' => [
                'required', 'string', 'max:100',
                Rule::unique(Department::getTableName())
                    ->where('faculty_id', $request->post('faculty_id'))
            ],
            'faculty_id' => 'required|numeric|exists:'.Faculty::getTableName().',id',
            'description' => 'nullable|string|max:500'
        ]);
        $item = Department::create($data);
        return response()->json([
            'success' => $item->name.' as bean created'
        ]);
    }

    public function update (Request $request, $id)
    {
        $data = $request->validate([
            'name' => [
                'required', 'string', 'max:100',
                Rule::unique(Department::getTableName())
                    ->where('faculty_id', $request->post('faculty_id'))
                    ->ignore($id)
            ],
            'faculty_id' => 'required|numeric|exists:'.Faculty::getTableName().',id',
            'description' => 'nullable|string|max:500'
        ]);
        $item = Department::findOrFail($id);
        $item->update($data);
        return response()->json([
            'success' => $item->name.' as bean updated'
        ]);
    }

    public function status (Request $request, $id)
    {
        $data = $request->validate([
            'is_active' => 'required|numeric|in:0,1'
        ]);
        $item = Department::findOrFail($id);
        $item->update($data);
        return response()->json([
            'success' => $item->name.' as bean updated'
        ]);
    }

    public function delete ($id)
    {
        $item = Department::findOrFail($id);
        try{
            $item->delete();
            return response()->json([
                'success' => $item->name.' as bean deleted'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => $item->name.' can not be deleted. '.$e->getMessage()
            ]);
        }
    }
}
