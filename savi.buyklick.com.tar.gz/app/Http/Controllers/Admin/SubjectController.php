<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Subject;
use Illuminate\Http\Request;

class SubjectController extends Controller
{
    public function index ()
    {
        return view('admin.subject');
    }

    public function getAll (Request $request)
    {
        list($sort, $type, $query, $item) = getListItems($request, 'id,name,created_at');
        $items = Subject::when($query, function ($sql) use ($query) {
            $sql->where('name', 'like', "%$query%")
                ->orWhere('description', 'like', "%$query%");
        })
            ->orderBy($sort, $type)
            ->paginate($item);
        return response()->json($items);
    }

    public function submit (Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100|unique:'.Subject::getTableName(),
            'code' => 'required|string|min:2|max:10|unique:'.Subject::getTableName(),
            'description' => 'nullable|string|max:500'
        ]);
        $item = Subject::create($data);
        return response()->json([
            'success' => $item->name.' as bean created'
        ]);
    }

    public function update (Request $request, $id)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100|unique:'.Subject::getTableName().',name,'.$id,
            'code' => 'required|string|min:2|max:10|unique:'.Subject::getTableName().',code,'.$id,
            'description' => 'nullable|string|max:500'
        ]);
        $item = Subject::findOrFail($id);
        $item->update($data);
        return response()->json([
            'success' => $item->name.' as bean updated'
        ]);
    }

    public function status (Request $request, $id)
    {
        $data = $request->validate([
            'is_active' => 'required|numeric|in:0,1'
        ]);
        $item = Subject::findOrFail($id);
        $item->update($data);
        return response()->json([
            'success' => $item->name.' as bean updated'
        ]);
    }

    public function delete ($id)
    {
        $item = Subject::findOrFail($id);
        try{
            $item->delete();
            return response()->json([
                'success' => $item->name.' as bean deleted'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => $item->name.' can not be deleted. '.$e->getMessage()
            ]);
        }
    }
}
