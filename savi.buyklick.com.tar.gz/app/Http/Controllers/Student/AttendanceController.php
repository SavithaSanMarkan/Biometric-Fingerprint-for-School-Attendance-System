<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\StudentEnrollment;
use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    public function index ($id)
    {
        $subject = StudentEnrollment::where('student_id', '=', auth('student')->id())
            ->findOrFail($id);
        $today_present = Attendance::where('student_id', '=', auth('student')->id())
            ->where('student_enrollment_id', '=', $id)
            ->whereDate('created_at', '=', now()->toDateString())
            ->exists();
        $attendances = Attendance::where('student_id', '=', auth('student')->id())
            ->where('student_enrollment_id', '=', $id)
            ->orderBy('id', 'desc')
            ->paginate(30);
        return view('student.attendance', compact('attendances','subject', 'today_present'));
    }

    public function submit (Request $request, $id)
    {
        $subject = StudentEnrollment::where('student_id', '=', $request->user('student')->id)
            ->findOrFail($id);
        $attendance = Attendance::where('student_id', '=', $request->user('student')->id)
            ->where('student_enrollment_id', '=', $id)
            ->whereDate('created_at', '=', now()->toDateString())
            ->exists();
        if(!$attendance) {
            Attendance::create([
                'student_enrollment_id' => $subject->id,
                'student_id' => auth('student')->id()
            ]);
        }
        return redirect()
            ->route('student.attendance.view', ['id' => $id])
            ->with('success', 'Attendance submitted');
    }
}
