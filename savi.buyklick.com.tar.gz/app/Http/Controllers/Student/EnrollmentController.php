<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\Student;
use App\Models\StudentEnrollment;
use App\Models\Subject;
use App\Models\SubjectEnrollment;
use App\Models\SubjectTime;
use App\Models\Teacher;
use Illuminate\Http\Request;

class EnrollmentController extends Controller
{
    public function index ()
    {
        return view('student.enrollment');
    }

    public function getAll (Request $request)
    {
        list($sort, $type, $query, $item) = getListItems($request, 'id,created_at');
        $items = \DB::table(StudentEnrollment::getTableName().' as e')
            ->selectRaw("`e`.`id`, d.`name` as `department_name`, `t`.`timetable`, `se`.`intake`,
                concat(`tc`.`identity`, ' - ', `tc`.`name`) as `name`,
                concat(`sub`.`code`, ' ', `sub`.`name`) as `subject_name`")
            ->join(Teacher::getTableName().' as tc', 'tc.id', '=', 'e.student_id')
            ->join(SubjectTime::getTableName().' as t', 't.id', '=', 'e.subject_time_id')
            ->join(SubjectEnrollment::getTableName().' as se', 'se.id', '=', 't.subject_enrollment_id')
            ->join(Subject::getTableName().' as sub', 'sub.id', '=', 'se.subject_id')
            ->join(Department::getTableName().' as d', 'd.id', '=', 'se.department_id')
            ->where('e.student_id', '=', auth('student')->id())
            ->when($query, function ($sql) use ($query) {
                $sql->where(function($q) use ($query) {
                    $q->where('tc.identity', '=', $query)
                        ->orWhere('tc.name', 'like', "%$query%")
                        ->orWhere('se.intake', '=', $query)
                        ->orWhere('sub.code', '=', $query)
                        ->orWhere('sub.name', 'like', "%$query%")
                        ->orWhere('d.name', 'like', "%$query%");
                });
            })
            ->orderBy('e.'.$sort, $type)
            ->paginate($item);
        return response()->json($items);
    }
}
