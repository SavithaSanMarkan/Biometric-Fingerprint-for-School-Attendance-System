<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Student;
use App\Models\Teacher;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    protected $role = 'email';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except(['logout','redirect']);
    }

    /**
     * Validate the user login request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return void
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    protected function validateLogin(Request $request)
    {
        $role = $request->post('role');
        $rule = 'required|email|min:4|max:100';
        if ($role == 'student') {
            $this->role = 'metric_id';
            $rule = 'required|alpha_num|min:2|max:15';
            $request->merge([$this->username() => $request->post('email')]);
        }
        $request->validate([
            $this->username() => $rule,
            'role' => 'required|alpha|in:teacher,student,web|max:50',
            'password' => 'required|string|min:1|max:15',
        ]);
    }

    protected function getAuthUserLogout ()
    {
        \Artisan::call('optimize:clear');
        \auth('student')->logout();
        \auth('teacher')->logout();
        \auth('web')->logout();
    }

    protected function username()
    {
        return $this->role;
    }

    protected function credentials(Request $request)
    {
        return $request->only($this->username(), 'password');
    }

    public function redirect (Request $request)
    {
        $user = $request->user('student') ?: $request->user('teacher') ?: $request->user('web');
        if ($user instanceof Student) {
            auth()->shouldUse('student');
            return redirect()->route('student.dashboard.view');
        }

        elseif ($user instanceof Teacher) {
            auth()->shouldUse('teacher');
            return redirect()->route('teacher.dashboard.view');
        }

        elseif ($user instanceof User) {
            auth()->shouldUse('web');
            return redirect()->route('admin.dashboard.view');
        }

        return $this->logout($request);
    }

    /**
     * The user has logged out of the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return mixed
     */
    protected function loggedOut(Request $request)
    {
        $this->getAuthUserLogout();
        return $request->wantsJson()
            ? new JsonResponse([], 204)
            : redirect()->route('login');
    }

    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard()
    {
        $guard =  \request()->post('role') ?: 'web';
        auth()->shouldUse($guard);
        return Auth::guard($guard);
    }
}
