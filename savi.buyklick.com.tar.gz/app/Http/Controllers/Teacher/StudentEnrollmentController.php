<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\Student;
use App\Models\StudentEnrollment;
use App\Models\Subject;
use App\Models\SubjectEnrollment;
use App\Models\SubjectTime;
use App\Models\TeacherEnrollment;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Validation\Rule;

class StudentEnrollmentController extends Controller
{
    public function index ()
    {
        $subjects = \DB::table(TeacherEnrollment::getTableName(). ' as u')
            ->join(SubjectTime::getTableName().' as t', 't.id', '=', 'u.subject_time_id')
            ->join(SubjectEnrollment::getTableName().' as e', 'e.id', '=', 't.subject_enrollment_id')
            ->join(Subject::getTableName().' as s', 's.id', '=', 'e.subject_id')
            ->selectRaw("`t`.`id`, concat(`s`.`code`, ' ', `s`.`name`, ' (', `e`.`intake`, ' - Time: ', `t`.`timetable`, ')') as `name`")
            ->where('u.teacher_id', '=', auth('teacher')->id())
            ->orderBy('s.name')
            ->orderByDesc('e.intake')
            ->orderByDesc('t.timetable')
            ->get();
        return view('teacher.student-enrollment', compact('subjects'));
    }

    public function getAll (Request $request)
    {
        list($sort, $type, $query, $item) = getListItems($request, 'id,created_at');
        $items = \DB::table(StudentEnrollment::getTableName().' as e')
            ->selectRaw("`e`.`id`, d.`name` as `department_name`, `t`.`timetable`, `se`.`intake`,
                concat(`s`.`metric_id`, ' - ', `s`.`name`) as `name`,
                concat(`sub`.`code`, ' ', `sub`.`name`) as `subject_name`")
            ->join(Student::getTableName().' as s', 's.id', '=', 'e.student_id')
            ->join(SubjectTime::getTableName().' as t', 't.id', '=', 'e.subject_time_id')
            ->join(SubjectEnrollment::getTableName().' as se', 'se.id', '=', 't.subject_enrollment_id')
            ->join(Subject::getTableName().' as sub', 'sub.id', '=', 'se.subject_id')
            ->join(Department::getTableName().' as d', 'd.id', '=', 'se.department_id')
            ->where('e.enrolled_by', '=', auth('teacher')->id())
            ->when($query, function ($sql) use ($query) {
                $sql->where(function($q) use ($query) {
                    $q->where('s.metric_id', '=', $query)
                        ->orWhere('s.name', 'like', "%$query%")
                        ->orWhere('se.intake', '=', $query)
                        ->orWhere('sub.code', '=', $query)
                        ->orWhere('sub.name', 'like', "%$query%")
                        ->orWhere('d.name', 'like', "%$query%");
                });
            })
            ->orderBy('e.'.$sort, $type)
            ->paginate($item);
        return response()->json($items);
    }

    public function submit (Request $request)
    {
        $student =  Student::select('id')
            ->where('metric_id', '=', $request->post('student_id'))
            ->first();
        if (!$student) {
            return response()->json([
                'message' => 'The given data was invalid',
                'errors' => [
                    'student_id' => ['Student not found']
                ]
            ], Response::HTTP_UNPROCESSABLE_ENTITY);
        }
        $request->merge(['student_id' => $student->id]);
        $data = $request->validate([
            'subject_time_id' => [
                'required', 'numeric', 'exists:'.SubjectTime::getTableName().',id',
                Rule::exists(TeacherEnrollment::getTableName(), 'subject_time_id')
                    ->where('teacher_id', $request->user('teacher')->id)
            ],
            'student_id' => [
                'required', 'numeric',
                Rule::unique(StudentEnrollment::getTableName(), 'student_id')
                    ->where('subject_time_id', $request->post('subject_time_id'))
                    ->where('enrolled_by', $request->user('teacher')->id)
            ]
        ]);
        $data['enrolled_by'] = $request->user('teacher')->id;
        $data['student_id'] = $student->id;
        $item = StudentEnrollment::create($data);
        $name = $item->student->name;
        return response()->json([
            'success' => $name.' as bean created'
        ]);
    }

    public function delete ($id)
    {
        $item = StudentEnrollment::where('enrolled_by', '=', auth('teacher')->id())
            ->findOrFail($id);
        $name = $item->student->name;
        try {
            $item->delete();
            return response()->json([
                'success' => $name.' as bean deleted'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => $name.' can not be deleted. '.$e->getMessage()
            ]);
        }
    }
}
