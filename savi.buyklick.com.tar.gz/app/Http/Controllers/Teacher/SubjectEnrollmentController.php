<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\Subject;
use App\Models\SubjectEnrollment;
use App\Models\SubjectTime;
use App\Models\TeacherEnrollment;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SubjectEnrollmentController extends Controller
{
    public function index ()
    {
        $subjects = \DB::table(SubjectTime::getTableName(). ' as t')
            ->join(SubjectEnrollment::getTableName().' as e', 'e.id', '=', 't.subject_enrollment_id')
            ->join(Subject::getTableName().' as s', 's.id', '=', 'e.subject_id')
            ->selectRaw("`t`.`id`, concat(`s`.`code`, ' ', `s`.`name`, ' (', `e`.`intake`, ' - Time: ', `t`.`timetable`, ')') as `name`")
            ->orderBy('s.name')
            ->orderByDesc('e.intake')
            ->orderByDesc('t.timetable')
            ->get();
        return view('teacher.subject-enrollment', compact('subjects'));
    }

    public function getAll (Request $request)
    {
        list($sort, $type, $query, $item) = getListItems($request, 'id,created_at');
        $items = TeacherEnrollment::with([
            'subject_time' => function ($sql) {
                $sql->with([
                    'subject_enrollment' => function ($sql) {
                        $sql->with(['subject:id,code,name','department:id,name'])
                            ->select('id', 'subject_id', 'department_id', 'intake');
                    }
                ])
                    ->select('id', 'subject_enrollment_id', 'timetable');
            }
        ])
            ->where('teacher_id', '=', auth('teacher')->id())
            ->orderBy($sort, $type)
            ->paginate($item);
        return response()->json($items);
    }

    public function submit (Request $request)
    {
        $data = $request->validate([
            'subject_time_id' => [
                'required', 'numeric', 'exists:'.SubjectTime::getTableName().',id',
                Rule::unique(TeacherEnrollment::getTableName(), 'subject_time_id')
                    ->where('teacher_id', $request->user('teacher')->id)
            ],
        ]);
        $data['teacher_id'] = $request->user('teacher')->id;
        $item = TeacherEnrollment::create($data);
        $name = $item->subject_time->subject_enrollment->subject->name;
        return response()->json([
            'success' => $name.' as bean created'
        ]);
    }

    public function delete ($id)
    {
        $item = TeacherEnrollment::where('teacher_id', '=', auth('teacher')->id())
            ->findOrFail($id);
        $name = $item->subject_time->subject_enrollment->subject->name;
        try {
            $item->delete();
            return response()->json([
                'success' => $name.' as bean deleted'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => $name.' can not be deleted. '.$e->getMessage()
            ]);
        }
    }
}
