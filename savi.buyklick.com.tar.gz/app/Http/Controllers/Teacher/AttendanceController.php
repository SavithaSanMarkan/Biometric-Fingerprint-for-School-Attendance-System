<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\StudentEnrollment;
use Illuminate\Http\Request;

class AttendanceController extends Controller
{
    public function index($id)
    {
        $subject = StudentEnrollment::where('enrolled_by', '=', auth('teacher')->id())
            ->findOrFail($id);
        $today_present = Attendance::where('student_enrollment_id', '=', $id)
            ->whereDate('created_at', '=', now()->toDateString())
            ->exists();
        $attendances = \DB::table(Attendance::getTableName().' as a')
            ->select('a.*')
            ->join(StudentEnrollment::getTableName(). ' as e', 'e.id', '=', 'a.student_enrollment_id')
            ->where('e.enrolled_by', '=', auth('teacher')->id())
            ->where('a.student_enrollment_id', '=', $id)
            ->orderBy('a.id', 'desc')
            ->paginate(30);
        return view('teacher.attendance', compact('attendances', 'subject', 'today_present'));
    }

    public function create(Request $request, $id)
    {
        $enroll = StudentEnrollment::findOrFail($id);
        $finger_print1 = json_decode($enroll->student->finger_print1);
        $finger_print2 = json_decode($enroll->student->finger_print2);
    }

    public function enroll(Request $request, $id)
    {
        $enroll = StudentEnrollment::findOrFail($id);
        $enroll->student->update([
            'finger_print1' => json_encode($request->post('fp1'), JSON_UNESCAPED_SLASHES),
            'finger_print2' => $request->post('fp2', JSON_UNESCAPED_SLASHES),
        ]);
        return response()->json();
    }
}
