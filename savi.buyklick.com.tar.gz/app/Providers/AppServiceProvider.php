<?php

namespace App\Providers;

use App\Models\AppSetting;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(127);
        $app_settings = Cache::get('app_settings');
        if(empty($app_settings)) {
            $table = AppSetting::getTableName();
            if (DB::connection()->getDatabaseName() && Schema::hasTable($table)) {
                $app_settings = DB::table($table)
                    ->pluck('value','name')
                    ->toArray();
                Cache::put('app_settings', $app_settings);
            }
        }
        \config()->set('app.settings', $app_settings);
        if ($app_settings && isset($app_settings['name']) && $app_settings['name']) {
            config()->set('app.name', $app_settings['name']);
        }
    }
}
