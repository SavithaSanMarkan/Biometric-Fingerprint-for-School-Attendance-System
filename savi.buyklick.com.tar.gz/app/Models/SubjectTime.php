<?php

namespace App\Models;

use App\Models\Config\BaseModel;

class SubjectTime extends BaseModel
{
    protected static $logName = 'subject_time';

    protected $fillable = [
        'subject_enrollment_id',
        'timetable'
    ];

    public function subject_enrollment ()
    {
        return $this->belongsTo(SubjectEnrollment::class);
    }
}
