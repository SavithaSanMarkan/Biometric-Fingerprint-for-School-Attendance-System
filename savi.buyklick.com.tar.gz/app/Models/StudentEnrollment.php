<?php

namespace App\Models;

use App\Models\Config\BaseModel;

class StudentEnrollment extends BaseModel
{
    protected static $logName = 'student_enrollment';

    protected $fillable = [
        'subject_time_id',
        'student_id',
        'remark',
        'enrolled_by',
        'is_active'
    ];

    protected $casts = [
        'is_active' => 'boolean'
    ];

    public function subject_time ()
    {
        return $this->belongsTo(SubjectTime::class);
    }

    public function student ()
    {
        return $this->belongsTo(Student::class);
    }

    public function teacher ()
    {
        return $this->belongsTo(Teacher::class, 'enrolled_by');
    }
}
