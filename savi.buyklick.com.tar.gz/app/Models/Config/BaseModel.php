<?php

namespace App\Models\Config;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;

abstract class BaseModel extends Model
{
    use HasFactory, TableName, CreateLog;

    protected static array $logAttributesToIgnore = ['updated_at','created_at'];
}
