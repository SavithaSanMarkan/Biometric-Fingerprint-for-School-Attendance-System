<?php

namespace App\Models\Config;

use Jenssegers\Agent\Agent;
use Spatie\Activitylog\Models\Activity as BaseActivity;

class Activity extends BaseActivity
{
    /**
     * Indicates if the booting.
     */
    protected static function boot ()
    {
        parent::boot();
        static::saving(function (Activity $activity) {
            $agent = new Agent();
            $request = \request();
            $platform = $agent->platform();
            $browser = $agent->browser();
            $browser = trim($browser . ' ' . $agent->version($browser));
            $platform = trim($platform . ' ' . $agent->version($platform));

            $device = null;
            if($agent->isDesktop())
                $device = 'Desktop: '.$agent->device();
            elseif($agent->isPhone())
                $device = 'Phone: '.$agent->device();
            elseif($agent->isRobot())
                $device = 'Robot: '.$agent->robot();

            $activity->ip_address = $request->ip();
            $activity->method = $request->method();
            $activity->browser = $browser ?: null;
            $activity->platform = $platform ?: null;
            $activity->device = $device ? rtrim(trim($device), ':') : null;
            $activity->url = $request->fullUrl();
        });
    }
}
