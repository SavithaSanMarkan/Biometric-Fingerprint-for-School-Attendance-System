<?php

namespace App\Models\Config;

use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\CausesActivity;
use Spatie\Activitylog\Traits\LogsActivity;

trait CreateLog
{
    use CausesActivity, LogsActivity;

    protected static array $recordEvents = ['created', 'deleted', 'updated'];

    public function getActivitylogOptions(): LogOptions
    {
        $logName = 'default';
        try {
            $logName = $this->logName ?? static::getTableName();
        } catch (\Exception $e) {}
        return LogOptions::defaults()
            ->useLogName($logName)
            ->logOnly($this->fillable)
            ->logOnlyDirty()
            ->dontSubmitEmptyLogs();
    }
}
