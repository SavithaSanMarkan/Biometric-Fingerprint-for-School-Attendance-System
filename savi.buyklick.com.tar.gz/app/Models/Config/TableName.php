<?php

namespace App\Models\Config;

trait TableName
{
    public static function getTableName ($prefix = false)
    {
        $prefix = $prefix ? env('TABLE_PREFIX') : '';
        return $prefix.with(new static)->getTable();
    }
}
