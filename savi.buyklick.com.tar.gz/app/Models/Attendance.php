<?php

namespace App\Models;

use App\Models\Config\BaseModel;

class Attendance extends BaseModel
{
    protected static $logName = 'attendance';

    protected $fillable = [
        'student_enrollment_id',
        'student_id',
        'is_active',
        'is_approved',
        'remark',
        'approved_at',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'is_approved' => 'boolean',
        'approved_at' => 'datetime'
    ];

    public function student ()
    {
        return $this->belongsTo(Student::class);
    }

    public function student_enrollment ()
    {
        return $this->belongsTo(StudentEnrollment::class);
    }
}

