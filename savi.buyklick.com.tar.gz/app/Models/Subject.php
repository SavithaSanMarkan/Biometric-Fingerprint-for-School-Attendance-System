<?php

namespace App\Models;

use App\Models\Config\BaseModel;

class Subject extends BaseModel
{
    protected static $logName = 'subject';

    protected $fillable = [
        'name',
        'code',
        'description',
        'is_active'
    ];

    protected $casts = [
        'is_active' => 'boolean'
    ];
}
