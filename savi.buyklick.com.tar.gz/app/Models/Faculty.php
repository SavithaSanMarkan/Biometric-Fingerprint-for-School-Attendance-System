<?php

namespace App\Models;

use App\Models\Config\BaseModel;

class Faculty extends BaseModel
{
    protected static $logName = 'faculty';

    protected $fillable = [
        'name',
        'description',
        'is_active'
    ];

    protected $casts = [
        'is_active' => 'boolean'
    ];

    public function departments()
    {
        return $this->hasMany(Department::class);
    }
}
