<?php

namespace App\Models;

use App\Models\Config\BaseModel;

class TeacherEnrollment extends BaseModel
{
    protected static $logName = 'teacher_enrollment';

    protected $fillable = [
        'subject_time_id',
        'teacher_id',
        'remark',
        'is_active'
    ];

    protected $casts = [
        'is_active' => 'boolean'
    ];

    public function subject_time ()
    {
        return $this->belongsTo(SubjectTime::class);
    }

    public function teacher ()
    {
        return $this->belongsTo(Teacher::class);
    }
}
