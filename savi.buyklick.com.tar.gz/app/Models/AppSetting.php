<?php

namespace App\Models;

use App\Models\Config\BaseModel;

class AppSetting extends BaseModel
{
    protected static $logName = 'app_setting';

    protected $fillable = ['name', 'value'];
}
