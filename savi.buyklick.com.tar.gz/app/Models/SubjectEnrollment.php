<?php

namespace App\Models;

use App\Models\Config\BaseModel;

class SubjectEnrollment extends BaseModel
{
    protected static $logName = 'subject_enrollment';

    protected $fillable = [
        'department_id',
        'subject_id',
        'intake',
        'credit_hour',
        'remark',
        'is_active'
    ];

    protected $casts = [
        'is_active' => 'boolean'
    ];

    public function department ()
    {
        return $this->belongsTo(Department::class);
    }

    public function subject ()
    {
        return $this->belongsTo(Subject::class);
    }

    public function subject_times ()
    {
        return $this->hasMany(SubjectTime::class);
    }
}
