<?php

namespace App\Models;

use App\Models\Config\BaseModel;

class Department extends BaseModel
{
    protected static $logName = 'department';

    protected $fillable = [
        'name',
        'faculty_id',
        'description',
        'is_active'
    ];

    protected $casts = [
        'is_active' => 'boolean'
    ];

    public function faculty()
    {
        return $this->belongsTo(Faculty::class);
    }
}
