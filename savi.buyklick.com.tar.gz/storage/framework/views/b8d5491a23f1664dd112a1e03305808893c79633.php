<?php $__env->startSection('title', 'Subject'); ?>

<?php $__env->startSection('content'); ?>
    <div class="xs-pd-20-10 pd-ltr-20" id="admin-app">
        <div class="title pb-20">
            <h2 class="h3 mb-0">Subjects</h2>
        </div>

        <subject />
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('header'); ?>
    <script>
        window.appHelper.routes = {
            all: "<?php echo e(route('admin.settings_subject.view')); ?>",
            single: "<?php echo e(route('admin.settings_subject.create')); ?>"
        }
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('footer'); ?>
    <?php echo $__env->make('includes.vue-files', ['component' => 'js/admin.js'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/savi.buyklick.com/resources/views/admin/subject.blade.php ENDPATH**/ ?>