<script src="<?php echo e(asset('js/axios.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/vue.min.js')); ?>"></script>
<?php /**PATH /www/wwwroot/savi.buyklick.com/resources/views/includes/min-vue-files.blade.php ENDPATH**/ ?>