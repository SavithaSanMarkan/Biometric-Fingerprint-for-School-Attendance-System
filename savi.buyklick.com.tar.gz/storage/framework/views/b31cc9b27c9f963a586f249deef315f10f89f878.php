<?php $__env->startPush('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset("plugins/jquery-confirm/dist/jquery-confirm.min.css")); ?>">
<?php $__env->stopPush(); ?>
<script src="<?php echo e(asset('plugins/jquery-confirm/dist/jquery-confirm.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/moment.js')); ?>"></script>
<script src="<?php echo e(asset('js/collect.min.js')); ?>"></script>
<?php echo $__env->make('includes.min-vue-files', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="<?php echo e(asset($component)); ?>"></script>
<?php /**PATH /www/wwwroot/savi.buyklick.com/resources/views/includes/vue-files.blade.php ENDPATH**/ ?>