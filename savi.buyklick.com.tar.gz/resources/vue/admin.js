require('./mixin');

Vue.component('dashboard', require('./admin/DashboardComponent.vue').default);
Vue.component('profile', require('./admin/ProfileComponent.vue').default);
Vue.component('app-setting', require('./admin/AppSettingsComponent.vue').default);
Vue.component('faculty', require('./admin/FacultyComponent.vue').default);
Vue.component('subject', require('./admin/SubjectComponent.vue').default);
Vue.component('department', require('./admin/DepartmentComponent.vue').default);
Vue.component('students', require('./admin/StudentsComponent.vue').default);
Vue.component('teachers', require('./admin/TeachersComponent.vue').default);

Vue.component('subject-enrollment', require('./admin/SubjectEnrollmentComponent.vue').default);
Vue.component('subject-time', require('./admin/SubjectTimeComponent.vue').default);

const app = new Vue({
    el: '#admin-app',
});
