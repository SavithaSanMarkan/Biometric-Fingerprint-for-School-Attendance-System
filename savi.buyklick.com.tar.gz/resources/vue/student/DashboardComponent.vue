<template>

</template>

<script>
export default {
    name: "DashboardComponent"
}
</script>

<style scoped>

</style>
