<template>
    <div class="d-block">
        <div class="pd-20 card-box mb-30">
            <div class="clearfix">
                <div class="pull-left">
                    <h4 class="text-blue h4">Subject Enrolled</h4>
                </div>
            </div>
            <div class="row justify-content-end">
                <div class="col-md-4">
                    <div class="input-group my-2">
                        <input class="form-control form-control-sm form-control-sidebar" v-model="search.query"
                               type="search" placeholder="Search" aria-label="Search" @keyup.enter="onSearch">
                        <div class="input-group-append">
                            <button class="btn btn-sm btn-default" @click="onSearch">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table class="data-table table nowrap">
                    <thead>
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>Teacher</th>
                        <th>Department</th>
                        <th>Subject</th>
                        <th style="width: 200px">Intake</th>
                        <th style="width: 140px">Time</th>
                        <th style="width: 126px">Attendance</th>
                    </tr>
                    </thead>
                    <tbody v-if="outputs.data.length>0">
                    <tr v-for="(item, index) in outputs.data">
                        <td>{{ sl+index }}.</td>
                        <td>{{ item.name }}</td>
                        <td>{{ item.department_name }}</td>
                        <td>{{ item.subject_name }}</td>
                        <td>{{ item.intake }}</td>
                        <td>{{ item.timetable }}</td>
                        <td class="text-center">
                            <a :href="app_url+'/student/attendance/'+item.id" class="btn btn-sm btn-info">
                                <i class="bi bi-check-circle"></i>
                            </a>
                        </td>
                    </tr>
                    </tbody>
                    <tfoot v-else>
                    <tr>
                        <td colspan="6" class="text-center">Data not found...</td>
                    </tr>
                    </tfoot>
                </table>
            </div>
            <pagination v-if="outputs.data.length>0" :records="outputs" @onclicked="paginationClicked"/>
        </div>
    </div>
</template>

<script>
import Pagination from "../Pagination.vue";
import queryString from "query-string";

export default {
    name: "EnrollmentComponent",
    components: {Pagination},
    created() {
        let parsed = queryString.parse(location.search);
        this.search.item = !!parsed.item ? parsed.item : 10;
        this.search.page = !!parsed.page ? parsed.page : 1;
        this.search.sort = !!parsed.sort ? parsed.sort : "created_at";
        this.search.type = !!parsed.type ? parsed.type : "desc";
        this.search.query = !!parsed.query ? parsed.query : "";
        this.createdFirst();
    },
    methods: {
        onSearch() {
            this.search.page = 1;
            let q = queryString.stringify(this.search);
            let newUrl = (this.routes.all ? this.routes.all : '') + "?" + q;
            window.history.pushState({}, null, newUrl);
            this.getAll();
        }
    }
}
</script>

<style scoped>

</style>
