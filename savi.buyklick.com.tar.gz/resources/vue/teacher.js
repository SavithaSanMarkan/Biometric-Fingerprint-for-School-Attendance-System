require('./mixin');

Vue.component('dashboard', require('./teacher/DashboardComponent.vue').default);
Vue.component('profile', require('./teacher/ProfileComponent.vue').default);
Vue.component('subject-enrollment', require('./teacher/SubjectEnrollmentComponent.vue').default);
Vue.component('student-enrollment', require('./teacher/StudentEnrollmentComponent.vue').default);

const app = new Vue({
    el: '#teacher-app',
});
