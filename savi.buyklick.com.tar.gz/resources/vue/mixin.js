import queryString from "query-string";

window.axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

Array.prototype.remove = function() {
    let what, a = arguments, L = a.length, ax;
    while (L && this.length) {
        what = a[--L];
        while ((ax = this.indexOf(what)) !== -1) {
            this.splice(ax, 1);
        }
    } return this;
};

Vue.mixin({
    data() {
        return {
            sl: 1,
            app_url: window.appHelper.appUrl,
            file_url: window.appHelper.fileUrl,
            routes: window.appHelper.routes,
            errors: {},
            adl: false,
            vwl: false,
            outputs: {
                data: [],
                per_page: null
            },
            search: {
                item: 10,
                page: 1,
                sort: 'name',
                type: 'asc',
                query: ''
            },
            viewOne: {}
        }
    },
    filters: {
        dateFormat(value) {
            if(value) {
                let date = new Date(value);
                return moment(date).format('MMM DD, YYYY');
            } return value;
        },
        dateTimeFormat(value) {
            if(value) {
                let date = new Date(value);
                return moment(date).format('MMM DD, YYYY h:mma');
            } return value;
        },
        padStart(v) {
            return String(v).padStart(5, '0');
        },
        roundToTwo(num) {
            if(num>0) {
                return +(Math.round(num + "e+2") + "e-2");
            } return 0;
        }
    },
    created() {
        this.parseQueryString();
    },
    methods: {
        parseQueryString () {
            let parsed = queryString.parse(location.search);
            this.search.item = !!parsed.item ? parsed.item : 10;
            this.search.page = !!parsed.page ? parsed.page : 1;
            this.search.sort = !!parsed.sort ? parsed.sort : "created_at";
            this.search.type = !!parsed.type ? parsed.type : "desc";
            this.search.query = !!parsed.query ? parsed.query : "";
        },
        createdFirst() {
            this.parseQueryString();
            let q = queryString.stringify(this.search);
            let newUrl = (this.routes.all ? this.routes.all : '') + "?" + q;
            window.history.pushState({}, null, newUrl);
            this.getAll();
        },
        strReplace(text, replace, newStr) {
            return text.replace(replace, newStr);
        },
        isInt(n){
            return Number(n) === n && n % 1 === 0;
        },
        makeObj(n){
            return JSON.parse(JSON.stringify(n));
        },
        errorHandler(err) {
            if(err.response && err.response.data) {
                toastr.error(err.response.data.message);
                this.errors = err.response.data.errors ? err.response.data.errors : {};
            }
        },
        getAll() {
            let _this = this;
            _this.errors = {};
            _this.vwl = true;
            axios.post(_this.routes.all, _this.search).then((res) => {
                _this.vwl = false;
                _this.outputs = res.data;
                _this.sl = 1;
                if (_this.search.page > 1) {
                    _this.sl = ((_this.search.page - 1) * parseInt(_this.outputs.per_page)) + 1;
                }
            }).catch((err) => {
                _this.vwl = false;
                _this.errorHandler(err);
            });
        },
        paginationClicked(page) {
            this.updateQueryParams('page', page);
            this.getAll();
        },
        updateQueryParams(key, value) {
            let parsed = queryString.parse(location.search);
            let item = this.search.item = (key === 'item') ? value : (!!parsed.item ? parsed.item : 2);
            let page = this.search.page = (key === 'page') ? value : (!!parsed.page ? parsed.page : 1);
            let sort = this.search.sort = (key === 'sort') ? value : (!!parsed.sort ? parsed.sort : "created_at");
            let type = this.search.type = (key === 'type') ? value : (!!parsed.type ? parsed.type : "desc");
            let query = this.search.query = (key === 'query') ? value : (!!parsed.query ? parsed.query : "");
            let q = queryString.stringify({
                page, sort, type, query, item
            });
            let newUrl = (this.routes.all ? this.routes.all : '') + "?" + q;
            window.history.pushState({}, null, newUrl);
        },
        viewItem(item) {
            this.viewOne = item;
            $("#viewOneModal").modal({
                backdrop: 'static',
                keyboard: false
            });
        },
        removeItem(item) {
            let _this = this;
            $.confirm({
                icon: 'fa fa-trash',
                theme: 'bootstrap',
                closeIcon: true,
                animation: 'scale',
                dragWindowBorder: true,
                type: 'red',
                typeAnimated: true,
                title: 'Warning!',
                content: 'Are you sure want to delete "' + item.name + '"?',
                buttons: {
                    tryAgain: {
                        text: 'Yes. Delete it',
                        btnClass: 'btn-red',
                        action: function(){
                            _this.deleteHttpRequest(item.id);
                        }
                    },
                    Close: {
                        text: 'Close'
                    }
                }
            });
        },
        deleteHttpRequest(id) {
            let _this = this;
            _this.errors = {};
            _this.vwl = true;
            axios.delete(_this.routes.single + "/" + id).then((res) => {
                _this.vwl = false;
                if (res.data.success) {
                    $.alert({
                        title: 'Success',
                        icon: 'fa fa-check',
                        type: 'green',
                        btnClass: 'btn-primary',
                        content: res.data.success,
                        alignMiddle: true
                    });
                    if(_this.search.page >= 2 && _this.outputs.data.length === 1) {
                        _this.search.page -= 1;
                    }
                    _this.getAll();
                } else {
                    toastr.warning(res.data.message);
                }
            }).catch((err) => {
                _this.vwl = false;
                _this.errorHandler(err)
            });
        },
        changeStatus(event,id,status) {
            let _this = this;
            _this.errors = {};
            _this.vwl = true;
            axios.put(_this.routes.single + "/" + id, {is_active: status ? 0 : 1}).then((res) => {
                _this.vwl = false;
                if (res.data.success) {
                    $.alert({
                        title: 'Success',
                        icon: 'fa fa-check',
                        type: 'green',
                        btnClass: 'btn-primary',
                        content: res.data.success,
                        alignMiddle: true
                    });
                    _this.getAll();
                } else {
                    toastr.warning(res.data.message);
                }
            }).catch((err) => {
                _this.vwl = false;
                _this.errorHandler(err)
            });
        },
        modalOpen(id) {
            $('#'+id).modal({
                backdrop: 'static',
                keyboard: false
            });
        },
        modalClose(id) {
            $('#'+id).modal('toggle');
        },
        onSearch (e) {
            e.preventDefault();
            this.search.page = 1;
            let q = queryString.stringify(this.search);
            let newUrl = (this.routes.all ? this.routes.all : '') + "?" + q;
            window.history.pushState({}, null, newUrl);
            this.getAll();
        },
        isEmptyObject(value) {
            return Object.keys(value).length === 0 && value.constructor === Object;
        }
    }
});
