<template>
    <div class="d-flex justify-content-center" aria-label="Page navigation">
        <ul class="pagination">
            <li class="paginate_button page-item first" :class="records.current_page === 1 ? 'disabled' : null">
                <a class="page-link" href="#" @click.prevent="onFirstPageClicked">
                    First
                </a>
            </li>

            <li class="paginate_button page-item previous" :class="records.current_page === 1 ? 'disabled' : null">
                <a class="page-link" href="#" @click.prevent="onPreviousPageClicked">
                    Prev
                </a>
            </li>

            <li v-for="(value) in pageRange" :class="((records.current_page === value) ? 'active' : '')" class="paginate_button page-item" aria-current="page">
                <a class="page-link" href="#" @click.prevent="onClicked(value)">{{ value }}</a>
            </li>

            <li class="paginate_button page-item next" :class="records.current_page === records.last_page ? 'disabled' : null">
                <a class="page-link" href="#" @click.prevent="onNextPageClicked">
                    Next
                </a>
            </li>

            <li class="paginate_button page-item last" :class="records.current_page === records.last_page ? 'disabled' : null">
                <a class="page-link" href="#" @click.prevent="onLastPageClicked">
                    Last
                </a>
            </li>
        </ul>
    </div>
</template>

<script>
export default {
  name: "Pagination",
  props: {
    records: {
      type: Object,
      required: true,
      default: {
        current_page: 0
      }
    }
  },

  computed: {
    pageRange() {
      let { records } = this;
      if(records.last_page < 5){
        return this.range(1, (records.last_page + 1) );
      }
      if( (records.last_page - 2)  < records.current_page){
        return this.range( (records.last_page - 4), (records.last_page + 1) );
      }
      if(records.current_page > 3){
        return this.range( (records.current_page - 2), (records.current_page + 3) );
      }
      return this.range(1, 6);
    }
  },

  methods: {
    range(start, count) {
      let a = [];
      for (let i = start; i < count; i++) {
        a.push(i);
      } return a;
    },

    onClicked(value){
      if(this.records.current_page !== value) {
        this.$emit('onclicked', value);
      }
    },

    onNextPageClicked(){
      if(this.records.current_page < this.records.last_page){
        this.$emit('onclicked', (this.records.current_page + 1));
      }
    },

    onLastPageClicked(){
      if(this.records.current_page < this.records.last_page){
        this.$emit('onclicked', this.records.last_page);
      }
    },

    onFirstPageClicked(){
      if(this.records.current_page > 1){
        this.$emit('onclicked', 1);
      }
    },

    onPreviousPageClicked(){
      if(this.records.current_page > 1){
        this.$emit('onclicked', (this.records.current_page - 1));
      }
    }
  }
}
</script>
