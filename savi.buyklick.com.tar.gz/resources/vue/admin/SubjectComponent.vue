<template>
    <div class="card-box pb-10">
        <div class="h5 pd-20 mb-0">
            Subject List
            <button type="button" class="btn btn-sm btn-primary float-md-right" @click="addNewModal">
                <i class="fas fa-plus-square"></i>
                &nbsp; Add New
            </button>
        </div>

        <div class="card-body p-0">
            <div class="row justify-content-end">
                <div class="col-md-4">
                    <div class="input-group my-2">
                        <input class="form-control form-control-sm form-control-sidebar" v-model="search.query"
                               type="search" placeholder="Search" aria-label="Search" @keyup.enter="onSearch">
                        <div class="input-group-append">
                            <button class="btn btn-sm btn-default" @click="onSearch">
                                <i class="fas fa-search fa-fw"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <table class="table table-striped">
                <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th style="width: 260px">Name</th>
                    <th style="width: 100px">Code</th>
                    <th>Description</th>
                    <th style="width: 126px">Action</th>
                </tr>
                </thead>
                <tbody v-if="outputs.data.length>0">
                <tr v-for="(item, index) in outputs.data">
                    <td>{{ sl+index }}.</td>
                    <td>{{ item.name }}</td>
                    <td>{{ item.code }}</td>
                    <td v-html="item.description"></td>
                    <td>
                        <button type="button" @click="editItem(item)" class="btn btn-sm btn-info">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button type="button" @click="removeItem(item)" class="btn btn-sm btn-danger">
                            <i class="fas fa-times"></i>
                        </button>
                    </td>
                </tr>
                </tbody>
                <tfoot v-else>
                <tr>
                    <td colspan="4" class="text-center">Data not found...</td>
                </tr>
                </tfoot>
            </table>
            <pagination v-if="outputs.data.length>0" :records="outputs" @onclicked="paginationClicked"/>
        </div>

        <div class="modal fade" id="addModal">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">
                            <span v-if="adf.id && adf.id > 0">Edit</span>
                            <span v-else>Add</span> Subject
                        </h4>
                        <button :disabled="adl" type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="add-form" :action="routes.single" v-on:submit.prevent="onSubmit" method="POST" enctype="multipart/form-data">
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="name">Name*</label>
                                <input v-model="adf.name" :disabled="adl" required type="text" class="form-control" id="name" placeholder="Name"
                                       :class="errors.hasOwnProperty('name') ? 'is-invalid' : null">
                                <div v-if="errors.hasOwnProperty('name')" class="invalid-feedback">{{ errors.name[0] }}</div>
                            </div>
                            <div class="form-group">
                                <label for="code">Code*</label>
                                <input v-model="adf.code" :disabled="adl" required type="text" class="form-control" id="code" placeholder="Code"
                                       :class="errors.hasOwnProperty('code') ? 'is-invalid' : null">
                                <div v-if="errors.hasOwnProperty('code')" class="invalid-feedback">{{ errors.code[0] }}</div>
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea v-model="adf.description" :disabled="adl" class="form-control" rows="3" id="description" placeholder="Description"
                                          :class="errors.hasOwnProperty('description') ? 'is-invalid' : null"></textarea>
                                <div v-if="errors.hasOwnProperty('description')" class="invalid-feedback">{{ errors.description[0] }}</div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button :disabled="adl" type="button" class="btn btn-light-primary" data-dismiss="modal">Close</button>
                            <button :disabled="adl" type="submit" class="btn btn-primary">
                                <span v-if="adf.id && adf.id > 0">Update</span>
                                <span v-else>Submit</span>
                            </button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
    </div>
</template>

<script>
import Pagination from "../Pagination.vue";
export default {
    name: "SubjectComponent",
    components: {Pagination},
    created() {
        this.createdFirst();
    },
    data() {
        return {
            adf: {
                id: "",
                name: "",
                code: "",
                description: "",
                is_active: ""
            }
        }
    },
    methods: {
        onSearch() {
            this.search.page = 1;
            let q = queryString.stringify(this.search);
            let newUrl = (this.routes.all ? this.routes.all : '') + "?" + q;
            window.history.pushState({}, null, newUrl);
            this.getAll();
        },
        addNewModal() {
            this.adf = {};
            this.errors = {};
            $("#add-form").attr("action", this.routes.single)
            this.modalOpen('addModal');
        },
        onSubmit(e) {
            let _this = this;
            _this.errors = {};
            _this.adl = true;
            axios.post(e.target.action, _this.adf).then((res) => {
                _this.adl = false;
                if(res.data.success) {
                    toastr.success(res.data.success);
                    _this.modalClose('addModal');
                    _this.adf = {};
                    _this.getAll();
                } else {
                    toastr.warning(res.data.message);
                }
            }).catch((err) => {
                _this.adl = false;
                _this.errorHandler(err);
            });
        },
        editItem(item) {
            this.adf = JSON.parse(JSON.stringify(item));
            this.adf.description = item.description ? item.description : '';
            let url = this.routes.single+'/'+item.id
            $("#add-form").attr("action", url)
            this.errors = {};
            this.modalOpen('addModal');
        }
    }
}
</script>

<style scoped>

</style>
