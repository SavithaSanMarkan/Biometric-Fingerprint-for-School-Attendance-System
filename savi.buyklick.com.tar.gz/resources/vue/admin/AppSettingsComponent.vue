<template>

</template>

<script>
export default {
    name: "AppSettingsComponent",
    props:{
        setting:{
            required: false,
            type: Object
        }
    },
    created(){
        this.appSetting = this.makeObj(this.setting);
    },
    data() {
        return {
            file: {},
            appSetting: {
                name: '',
                mobile: '',
                email: '',
                phone: '',
                fax: '',
                address: '',
                logo: ''
            },
            adf: {
                name: '',
                mobile: '',
                email: '',
                phone: '',
                fax: '',
                address: ''
            }
        }
    },
    methods: {
        editModal() {
            this.adf = this.makeObj(this.appSetting);
            if(this.isEmptyObject(this.adf)) {
                this.adf = {};
            }
            this.errors = {};
            $("#edit-form").attr("action", this.routes.single)
            this.modalOpen('editModal');
        },
        editLogoModal () {
            this.file = {};
            document.getElementById('logo').value = '';
            this.errors = {};
            $("#edit-logo-form").attr("action", this.routes.single+'/logo')
            this.modalOpen('editLogoModal');
        },
        onSubmit(e) {
            let _this = this;
            _this.errors = {};
            _this.adl = true;
            let fd = new FormData();
            for ( let key in _this.adf) {
                fd.append(key, _this.adf[key]);
            }
            axios.post(e.target.action, fd).then((res) => {
                _this.adl = false;
                if(res.data.success) {
                    toastr.success(res.data.success);
                    _this.modalClose('editModal');
                    _this.adf = {};
                    _this.appSetting = res.data.settings;
                } else {
                    toastr.warning(res.data.message);
                }
            }).catch((err) => {
                _this.adl = false;
                _this.errorHandler(err);
            });
        },
        onSubmitLogo(e) {
            let _this = this;
            _this.errors = {};
            _this.adl = true;
            let fd = new FormData();
            fd.append('logo', _this.file);
            axios.post(e.target.action, fd).then((res) => {
                _this.adl = false;
                if(res.data.success) {
                    toastr.success(res.data.success);
                    _this.modalClose('editLogoModal');
                    document.getElementById('logo').value = '';
                    _this.file = {};
                    _this.appSetting.logo = res.data.logo;
                } else {
                    toastr.warning(res.data.message);
                }
            }).catch((err) => {
                _this.adl = false;
                _this.errorHandler(err);
            });
        },
        selectLogo () {
            let files = this.$refs.logo.files;
            if(files.length > 0) {
                this.file = files[0];
            }
        }
    }
}
</script>

<style scoped>

</style>
