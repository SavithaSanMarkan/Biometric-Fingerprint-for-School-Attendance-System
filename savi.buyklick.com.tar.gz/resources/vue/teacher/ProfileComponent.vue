<template>
    <div class="row">
        <div class="col-xl-7 col-lg-6 col-sm-12">
            <div class="card card-custom h-100">
                <div class="card-header flex-wrap py-3">
                    <div class="card-title">
                        <h4 class="card-label">
                            Profile
                            <button type="button" @click="editModal" class="btn btn-sm btn-primary float-md-right">
                                Edit Profile
                            </button>
                        </h4>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive table-responsive-sm">
                        <table class="table table-sm table-bordered table-hover table-striped mb-4">
                            <tbody>
                            <tr>
                                <td style="width: 125px;"><strong>Name</strong></td>
                                <td class="text-capitalize">{{ profile.name }}</td>
                            </tr>
                            <tr>
                                <td><strong>ID</strong></td>
                                <td>{{ profile.identity }}</td>
                            </tr>
                            <tr>
                                <td><strong>Email</strong></td>
                                <td>{{ profile.email }}</td>
                            </tr>
                            <tr>
                                <td><strong>Gender</strong></td>
                                <td class="text-capitalize">{{ profile.gender }}</td>
                            </tr>
                            <tr>
                                <td><strong>Created</strong></td>
                                <td>{{ profile.created_at | dateTimeFormat }}</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-5 col-lg-6 col-sm-12">
            <div class="card card-custom h-100">
                <div class="card-header flex-wrap py-3">
                    <div class="card-title">
                        <h4 class="card-label">Password Change</h4>
                    </div>
                </div>
                <div class="card-body">
                    <form :action="routes.single" method="POST" v-on:submit.prevent="onPassword" autocomplete="off">
                        <div class="form-group form-group-sm">
                            <label for="current_password">Current Password</label>
                            <input :disabled="adl" required v-model="adf.current_password" type="password" name="current_password"
                                   class="form-control" id="current_password" placeholder="Current Password"
                                   :class="errors.hasOwnProperty('current_password') ? 'is-invalid' : null">
                            <div v-if="errors.hasOwnProperty('current_password')" class="invalid-feedback">
                                {{ errors.current_password[0] }}
                            </div>
                        </div>
                        <div class="form-group form-group-sm">
                            <label for="password">New Password</label>
                            <input :disabled="adl" required v-model="adf.password" type="password" name="password"
                                   class="form-control" id="password" placeholder="New Password"
                                   :class="errors.hasOwnProperty('password') ? 'is-invalid' : null">
                            <div v-if="errors.hasOwnProperty('password')" class="invalid-feedback">
                                {{ errors.password[0] }}
                            </div>
                        </div>
                        <div class="form-group form-group-sm">
                            <label for="password_confirmation">Retype New Password</label>
                            <input :disabled="adl" required v-model="adf.password_confirmation" type="password" name="password_confirmation"
                                   class="form-control" id="password_confirmation" placeholder="Current Password"
                                   :class="errors.hasOwnProperty('password_confirmation') ? 'is-invalid' : null">
                            <div v-if="errors.hasOwnProperty('password_confirmation')" class="invalid-feedback">
                                {{ errors.password_confirmation[0] }}
                            </div>
                        </div>
                        <div class="form-group form-group-sm">
                            <button :disabled="adl" type="submit" class="btn btn-sm btn-primary float-right">
                                Change
                                <i v-if="adl" class="fas fa-circle-notch fa-spin"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Profile Modal-->
        <div class="modal fade" id="editModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdrop" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <span>Edit Profile</span>
                        </h5>
                        <button :disabled="adl" type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <i aria-hidden="true" class="ki ki-close"></i>
                        </button>
                    </div>
                    <form id="edit-form" :action="routes.single" v-on:submit.prevent="onSubmit" method="POST" enctype="multipart/form-data" autocomplete="off">
                        <div class="modal-body">
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label">Name:</label>
                                <div class="col-lg-8">
                                    <input required :disabled="adl" type="text" class="form-control" placeholder="Name"
                                           v-model="adf.name" :class="errors.hasOwnProperty('name') ? 'is-invalid' : null" />
                                    <div v-if="errors.hasOwnProperty('name')" class="invalid-feedback">{{ errors.name[0] }}</div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button :disabled="adl" type="button" class="btn btn-sm btn-light-primary" data-dismiss="modal">Close</button>
                            <button :disabled="adl" type="submit" class="btn btn-sm btn-primary">
                                <span>Update</span>
                                <span v-if="adl">
                                    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                    <span class="sr-only">Loading...</span>
                                </span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "ProfileComponent",
    props: {
        user: {
            required: true,
            type: Object
        }
    },
    data() {
        return {
            adf: {
                name: '',
                current_password: '',
                password: '',
                password_confirmation: ''
            },
            profile: {
                name: '',
                identity: '',
                gender: '',
                email: '',
                created_at: '',
            }
        }
    },
    created() {
        this.profile = this.user;
    },
    methods: {
        editModal() {
            this.adf = this.makeObj(this.profile);
            this.errors = {};
            $("#edit-form").attr("action", this.routes.single)
            this.modalOpen('editModal');
        },
        onSubmit(e) {
            let _this = this;
            _this.errors = {};
            _this.adl = true;
            axios.post(e.target.action, _this.adf).then((res) => {
                _this.adl = false;
                if(res.data.success) {
                    toastr.success(res.data.success);
                    _this.modalClose('editModal');
                    _this.adf = {};
                    _this.profile = res.data.profile;
                } else {
                    toastr.warning(res.data.message);
                }
            }).catch((err) => {
                _this.adl = false;
                _this.errorHandler(err);
            });
        },
        onPassword(e) {
            let _this = this;
            _this.errors = {};
            _this.adl = true;
            _this.adf._method = 'PATCH';
            axios.post(e.target.action, _this.adf).then((res) => {
                _this.adl = false;
                if(res.data.success) {
                    _this.adf = {};
                    toastr.success(res.data.success);
                } else {
                    toastr.warning(res.data.message);
                }
            }).catch((err) => {
                _this.adl = false;
                _this.errorHandler(err);
            });
        }
    }
}
</script>

<style scoped>

</style>
