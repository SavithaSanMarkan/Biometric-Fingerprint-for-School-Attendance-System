<template>
    <div class="d-block">
        <div class="pd-20 card-box mb-30">
            <div class="clearfix">
                <div class="pull-left">
                    <h4 class="text-blue h4">Student Enrollment</h4>
                </div>
            </div>
            <form id="add-form" :action="routes.single" v-on:submit.prevent="onSubmit" method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Select Subjects</label>
                            <select :disabled="adl" v-model="adf.subject_time_id" class="form-control" required
                                    :class="errors.hasOwnProperty('subject_time_id') ? 'is-invalid' : null">
                                <option value="">Select One</option>
                                <option v-for="item in subjects" :value="item.id">{{ item.name }}</option>
                            </select>
                            <div v-if="errors.hasOwnProperty('subject_time_id')" class="invalid-feedback">{{ errors.subject_time_id[0] }}</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Student ID</label>
                            <input :disabled="adl" v-model="adf.student_id" class="form-control" required type="text" maxlength="15" placeholder="Student ID"
                                   :class="errors.hasOwnProperty('student_id') ? 'is-invalid' : null"/>
                            <div v-if="errors.hasOwnProperty('student_id')" class="invalid-feedback">{{ errors.student_id[0] }}</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group pt-lg-4">
                            <button :disabled="adl" class="btn btn-primary btn-block scroll-click mt-lg-2" type="submit">
                                <i class="bi bi-send"></i> Enroll
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <div class="card-box pb-10">
            <div class="h5 pd-20 mb-0">Subject List</div>
            <div class="row justify-content-end">
                <div class="col-md-4">
                    <div class="input-group my-2">
                        <input class="form-control form-control-sm form-control-sidebar" v-model="search.query"
                               type="search" placeholder="Search" aria-label="Search" @keyup.enter="onSearch">
                        <div class="input-group-append">
                            <button class="btn btn-sm btn-default" @click="onSearch">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table class="data-table table nowrap">
                    <thead>
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>Student</th>
                        <th>Department</th>
                        <th>Subject</th>
                        <th style="width: 200px">Intake</th>
                        <th style="width: 140px">Time</th>
                        <th style="width: 100px">Attendance</th>
                        <th style="width: 96px">Action</th>
                    </tr>
                    </thead>
                    <tbody v-if="outputs.data.length>0">
                    <tr v-for="(item, index) in outputs.data">
                        <td>{{ sl+index }}.</td>
                        <td>{{ item.name }}</td>
                        <td>{{ item.department_name }}</td>
                        <td>{{ item.subject_name }}</td>
                        <td>{{ item.intake }}</td>
                        <td>{{ item.timetable }}</td>
                        <td class="text-center">
                            <a :href="app_url+'/teacher/attendance/'+item.id" class="btn btn-sm btn-info">
                                <i class="bi bi-check-circle"></i>
                            </a>
                        </td>
                        <td class="text-center">
                            <button type="button" @click="removeItem(item)" class="btn btn-sm btn-danger">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                    </tbody>
                    <tfoot v-else>
                    <tr>
                        <td colspan="7" class="text-center">Data not found...</td>
                    </tr>
                    </tfoot>
                </table>
            </div>
            <pagination v-if="outputs.data.length>0" :records="outputs" @onclicked="paginationClicked"/>
        </div>
    </div>
</template>

<script>
import Pagination from "../Pagination.vue";
import queryString from "query-string";

export default {
    name: "StudentEnrollmentComponent",
    props: {
        subjects: {
            required: true,
            type: Array
        }
    },
    components: { Pagination },
    created() {
        let parsed = queryString.parse(location.search);
        this.search.item = !!parsed.item ? parsed.item : 10;
        this.search.page = !!parsed.page ? parsed.page : 1;
        this.search.sort = !!parsed.sort ? parsed.sort : "created_at";
        this.search.type = !!parsed.type ? parsed.type : "desc";
        this.search.query = !!parsed.query ? parsed.query : "";
        this.createdFirst();
    },
    data() {
        return {
            adf: {
                id: "",
                subject_time_id: "",
                student_id: ""
            }
        }
    },
    methods: {
        onSearch() {
            this.search.page = 1;
            let q = queryString.stringify(this.search);
            let newUrl = (this.routes.all ? this.routes.all : '') + "?" + q;
            window.history.pushState({}, null, newUrl);
            this.getAll();
        },
        addNewModal() {
            this.adf = {};
            this.adf.subject_time_id = '';
            this.errors = {};
            $("#add-form").attr("action", this.routes.single)
            this.modalOpen('addModal');
        },
        onSubmit(e) {
            let _this = this;
            _this.errors = {};
            _this.adl = true;
            axios.post(e.target.action, _this.adf).then((res) => {
                _this.adl = false;
                if(res.data.success) {
                    toastr.success(res.data.success);
                    _this.adf = {};
                    _this.adf.subject_time_id = '';
                    _this.getAll();
                } else {
                    toastr.warning(res.data.message);
                }
            }).catch((err) => {
                _this.adl = false;
                _this.errorHandler(err);
            });
        }
    }
}
</script>

<style scoped>

</style>
