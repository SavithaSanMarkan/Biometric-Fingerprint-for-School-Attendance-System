require('./mixin');

Vue.component('dashboard', require('./student/DashboardComponent.vue').default);
Vue.component('profile', require('./student/ProfileComponent.vue').default);
Vue.component('enrollment', require('./student/EnrollmentComponent.vue').default);

new Vue({
    el: '#student-app',
});
