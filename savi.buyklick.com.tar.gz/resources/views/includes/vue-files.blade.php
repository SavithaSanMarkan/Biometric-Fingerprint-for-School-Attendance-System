@push('header')
<link rel="stylesheet" href="{{ asset("plugins/jquery-confirm/dist/jquery-confirm.min.css") }}">
@endpush
<script src="{{ asset('plugins/jquery-confirm/dist/jquery-confirm.min.js') }}"></script>
<script src="{{ asset('js/moment.js') }}"></script>
<script src="{{ asset('js/collect.min.js') }}"></script>
@include('includes.min-vue-files')
<script src="{{ asset($component) }}"></script>
