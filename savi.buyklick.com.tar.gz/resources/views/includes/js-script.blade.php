<script type="text/javascript">
    $(function () {
        $('[data-tooltip="tooltip"]').tooltip();
    });
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
</script>

@if(session()->has(['success','error','warning','message']))
    <script type="text/javascript">
        $(function() {
            @if($msg = session('success'))
            toastr.success('{!! $msg !!}');
            @elseif($msg = session('error'))
            toastr.error('{!! $msg !!}');
            @elseif($msg = session('warning'))
            toastr.warning('{!! $msg !!}');
            @else
            toastr.info('{!! session('message') !!}');
            @endif
        });
    </script>
@endif
