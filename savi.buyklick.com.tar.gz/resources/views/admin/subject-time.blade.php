@extends('admin.master')

@section('title', 'Subject Timetable')

@section('content')
    <div class="xs-pd-20-10 pd-ltr-20" id="admin-app">
        <div class="title pb-20">
            <h2 class="h3 mb-0">Subject Timetable</h2>
        </div>

        <subject-time :subjects='@json($subjects)' />
    </div>
@endsection

@push('header')
    <script>
        window.appHelper.routes = {
            all: "{{ route('admin.subject_time.view') }}",
            single: "{{ route('admin.subject_time.create') }}"
        }
    </script>
@endpush

@push('footer')
    @include('includes.vue-files', ['component' => 'js/admin.js'])
@endpush
