@extends('admin.master')

@section('title', 'Faculty')

@section('content')
    <div class="xs-pd-20-10 pd-ltr-20" id="admin-app">
        <div class="title pb-20">
            <h2 class="h3 mb-0">Faculties</h2>
        </div>

        <faculty />
    </div>
@endsection

@push('header')
    <script>
        window.appHelper.routes = {
            all: "{{ route('admin.settings_faculty.view') }}",
            single: "{{ route('admin.settings_faculty.create') }}"
        }
    </script>
@endpush

@push('footer')
    @include('includes.vue-files', ['component' => 'js/admin.js'])
@endpush
