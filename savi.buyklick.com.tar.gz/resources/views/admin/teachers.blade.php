@extends('admin.master')

@section('title', 'Teachers')

@section('content')
    <div class="xs-pd-20-10 pd-ltr-20" id="admin-app">
        <div class="title pb-20">
            <h2 class="h3 mb-0">Teachers</h2>
        </div>

        <teachers />
    </div>
@endsection

@push('header')
    <script>
        window.appHelper.routes = {
            all: "{{ route('admin.teacher.view') }}",
            single: "{{ route('admin.teacher.create') }}"
        }
    </script>
@endpush

@push('footer')
    @include('includes.vue-files', ['component' => 'js/admin.js'])
@endpush
