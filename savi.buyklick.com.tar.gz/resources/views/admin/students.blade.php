@extends('admin.master')

@section('title', 'Students')

@section('content')
    <div class="xs-pd-20-10 pd-ltr-20" id="admin-app">
        <div class="title pb-20">
            <h2 class="h3 mb-0">Students</h2>
        </div>

        <students />
    </div>
@endsection

@push('header')
    <script>
        window.appHelper.routes = {
            all: "{{ route('admin.student.view') }}",
            single: "{{ route('admin.student.create') }}"
        }
    </script>
@endpush

@push('footer')
    @include('includes.vue-files', ['component' => 'js/admin.js'])
@endpush
