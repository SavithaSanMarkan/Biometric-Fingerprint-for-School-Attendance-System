@extends('admin.master')

@section('title', 'App Settings')

@section('content')

@endsection
