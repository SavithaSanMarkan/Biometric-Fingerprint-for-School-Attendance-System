@extends('student.master')

@section('title', 'Subject Enrolled')

@section('content')
    <div class="xs-pd-20-10 pd-ltr-20" id="student-app">
        <div class="title pb-20">
            <h2 class="h3 mb-0">Subject Enrolled</h2>
        </div>

        <enrollment />
    </div>
@endsection

@push('header')
    <script>
        window.appHelper.routes = {
            all: "{{ route('student.enrollment.view') }}"
        }
    </script>
@endpush

@push('footer')
    @include('includes.vue-files', ['component' => 'js/student.js'])
@endpush
