@extends('student.master')

@section('title', 'Subject Wise Attendance')

@section('content')
    <div class="xs-pd-20-10 pd-ltr-20" id="student-app">
        <div class="title pb-20">
            <h2 class="h3 mb-0">Subject Wise Attendance</h2>
        </div>
    </div>
    <div class="m-3">
        <div class="card-box pb-10">
            <div class="h5 pd-20 mb-0">
                Subject Information
            </div>
            <div class="card-body p-0">
                <div class="row">
                    <div class="col-md-6">
                        <div class="table-responsive">
                            <table class="data-table table nowrap">
                                <tbody>
                                <tr>
                                    <td style="width: 140px">Teacher</td>
                                    <td style="width: 5px;">:</td>
                                    <td>{{ $subject->teacher->identity.' - '.$subject->teacher->name }}</td>
                                </tr>
                                <tr>
                                    <td>Subject</td>
                                    <td>:</td>
                                    <td>{{ $subject->subject_time->subject_enrollment->subject->code . ' ' .$subject->subject_time->subject_enrollment->subject->name }}</td>
                                </tr>
                                <tr>
                                    <td>Department</td>
                                    <td>:</td>
                                    <td>{{ $subject->subject_time->subject_enrollment->department->name }}</td>
                                </tr>
                                <tr>
                                    <td>Intake &amp; Time</td>
                                    <td>:</td>
                                    <td>
                                        {{ $subject->subject_time->subject_enrollment->intake }} -
                                        {{ $subject->subject_time->timetable }}
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex align-items-center justify-content-center">
                        @if($today_present)
                            <h2>Today Present</h2>
                        @else
                            <form method="POST" action="{{ route('student.attendance.create', ['id' => $subject->id]) }}">
                                @csrf
                                <button type="submit" class="btn btn-lg btn-primary">
                                    Submit Attendance
                                </button>
                            </form>
                        @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div class="card-box pb-10">
            <div class="h5 pd-20 mb-0">
                Attendance Log
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="data-table table nowrap">
                        <thead>
                        <tr>
                            <th style="width: 20px">#</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Time</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($attendances as $item)
                            <tr>
                                <td>{{ $loop->iteration + $attendances->firstItem() - 1 }}</td>
                                <td>{{ $item->created_at->toDateString() }}</td>
                                <td>Present</td>
                                <td>{{ $item->created_at->toTimeString() }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-center">
                    {!! $attendances->links() !!}
                </div>
            </div>
        </div>
    </div>
@endsection
