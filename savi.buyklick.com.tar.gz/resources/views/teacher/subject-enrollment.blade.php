@extends('teacher.master')

@section('title', 'Subject Enrollment')

@section('content')
    <div class="xs-pd-20-10 pd-ltr-20" id="teacher-app">
        <div class="title pb-20">
            <h2 class="h3 mb-0">Subject Enrollment</h2>
        </div>

        <subject-enrollment :subjects='@json($subjects)' />
    </div>
@endsection

@push('header')
    <script>
        window.appHelper.routes = {
            all: "{{ route('teacher.subject_enrollment.view') }}",
            single: "{{ route('teacher.subject_enrollment.create') }}"
        }
    </script>
@endpush

@push('footer')
    @include('includes.vue-files', ['component' => 'js/teacher.js'])
@endpush
