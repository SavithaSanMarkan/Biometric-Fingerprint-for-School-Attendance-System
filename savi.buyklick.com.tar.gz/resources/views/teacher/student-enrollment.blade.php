@extends('teacher.master')

@section('title', 'Student Enrollment')

@section('content')
    <div class="xs-pd-20-10 pd-ltr-20" id="teacher-app">
        <div class="title pb-20">
            <h2 class="h3 mb-0">Student Enrollment</h2>
        </div>

        <student-enrollment :subjects='@json($subjects)' />
    </div>
@endsection

@push('header')
    <script>
        window.appHelper.routes = {
            all: "{{ route('teacher.student_enrollment.view') }}",
            single: "{{ route('teacher.student_enrollment.create') }}"
        }
    </script>
@endpush

@push('footer')
    @include('includes.vue-files', ['component' => 'js/teacher.js'])
@endpush
