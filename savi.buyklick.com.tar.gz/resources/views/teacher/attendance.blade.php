@extends('teacher.master')

@section('title', 'Subject Wise Attendance')

@section('content')
    <div class="xs-pd-20-10 pd-ltr-20" id="student-app">
        <div class="title pb-20">
            <h2 class="h3 mb-0">Subject Wise Attendance</h2>
        </div>
    </div>
    <div class="m-3">
        <div class="card-box pb-10">
            <div class="h5 pd-20 mb-0">
                Subject Information
            </div>
            <div class="card-body p-0">
                <div class="row">
                    <div class="col-md-6">
                        <div class="table-responsive">
                            <table class="data-table table nowrap">
                                <tbody>
                                <tr>
                                    <td style="width: 160px">Student</td>
                                    <td style="width: 5px;">:</td>
                                    <td>{{ $subject->student->metric_id.' - '.$subject->student->name }}</td>
                                </tr>
                                <tr>
                                    <td>Subject</td>
                                    <td>:</td>
                                    <td>{{ $subject->subject_time->subject_enrollment->subject->code . ' ' .$subject->subject_time->subject_enrollment->subject->name }}</td>
                                </tr>
                                <tr>
                                    <td>Department</td>
                                    <td>:</td>
                                    <td>{{ $subject->subject_time->subject_enrollment->department->name }}</td>
                                </tr>
                                <tr>
                                    <td>Intake &amp; Time</td>
                                    <td>:</td>
                                    <td>
                                        {{ $subject->subject_time->subject_enrollment->intake }} -
                                        {{ $subject->subject_time->timetable }}
                                    </td>
                                </tr>
                                <tr>
                                    <td>Has Fingerprints</td>
                                    <td>:</td>
                                    <td id="hasFp">{{ $subject->student->finger_print1 && $subject->student->finger_print2 ? 'Yes' : 'No' }}</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="clearfix px-5">
                                    <button type="button" id="enrollBtn" class="btn btn-sm btn-info float-left">Biometric Enroll</button>
                                    <button type="button" id="attendanceBtn" class="btn btn-sm btn-secondary float-right">Biometric Attendance</button>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="d-flex align-items-center justify-content-center mt-3">
                                    @if($today_present)
                                        <h2>Today Present</h2>
                                    @else
                                        <h2>Today Absent</h2>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div class="card-box pb-10">
            <div class="h5 pd-20 mb-0">
                Attendance Log
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="data-table table nowrap">
                        <thead>
                        <tr>
                            <th style="width: 20px">#</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Time</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($attendances as $item)
                            <tr>
                                <td>{{ $loop->iteration + $attendances->firstItem() - 1 }}</td>
                                <td>{{ \Illuminate\Support\Carbon::parse($item->created_at)->toDateString() }}</td>
                                <td>Present</td>
                                <td>{{ \Illuminate\Support\Carbon::parse($item->created_at)->toTimeString() }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-center">
                    {!! $attendances->links() !!}
                </div>
            </div>
        </div>
        <div class="modal fade" id="enrollModal" tabindex="-1" role="dialog" aria-labelledby="enrollModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="enrollModalLabel">Attendance Enroll</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body p-2">
                        <div class="row">
                            <div class="col-md-4">
                                <button type="button" id="take1Btn" class="btn btn-sm btn-info btn-block mt-2">Take FP 1</button>
                                <button type="button" id="take2Btn" class="btn btn-sm btn-secondary btn-block mt-4">Take FP 2</button>
                                <button type="button" id="resetBtn" class="btn btn-sm btn-danger btn-block mt-4">Reset FP</button>
                            </div>
                            <div class="col-md-4">
                                <img id="fpImg1" src="#" class="d-none" alt="Fingerprint Image" style="width: 100%">
                                <img id="fpImg1" src="#" class="d-none" alt="Fingerprint Image" style="width: 100%">
                            </div>
                            <div class="col-md-4">
                                <img id="fpImg2" src="#" class="d-none" alt="Fingerprint Image" style="width: 100%">
                            </div>
                        </div>
                        <p id="mgsP" class="d-none text-center">Fingerprint enrollment done</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="attendanceModal" tabindex="-1" role="dialog" aria-labelledby="attendanceModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="enrollModalLabel">Attendance</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body p-2">
                        <div class="row">
                            <div class="col-md-5 py-3">
                                <button type="button" id="takeAtnBtn" class="btn btn-sm btn-info btn-block my-5">Take Fingerprint</button>
                            </div>
                            <div class="col-md-7">
                                <img id="fpAtnImg" src="#" class="d-none" alt="Fingerprint Image" style="width: 100%">
                            </div>
                        </div>
                        <p id="mgsAtnP" class="d-none text-center">Fingerprint Attendance Done</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('footer')
    <script type="text/javascript">
        var fp1 = null;
        var fp2 = null;
        var fp3 = null;

        $(document).ready(function () {
            var mgsEl = $('#mgsP');
            var mgsAtnP = $('#mgsAtnP');

            var fpImg1 = $('#fpImg1');
            var fpImg2 = $('#fpImg2');
            var fpAtnImg = $('#fpAtnImg');

            var take1Btn = $('#take1Btn');
            var take2Btn = $('#take2Btn');
            var resetBtn = $('#resetBtn');

            var takeAtnBtn = $('#takeAtnBtn');

            var enEl = $('#enrollBtn');
            var atEl = $('#attendanceBtn');
            var enMdEl = $('#enrollModal');
            var atnMdEl = $('#attendanceModal');

            enEl.on('click', function () {
                resetBtn.click();
                enMdEl.modal({
                    keyboard: false,
                    backdrop: 'static',
                });
            });

            atEl.on('click', function () {
                fp3 = null;
                fpAtnImg.addClass('d-none');
                fpAtnImg.attr('src', '');
                mgsAtnP.addClass('d-none')
                mgsAtnP.removeClass('d-block')
                atnMdEl.modal({
                    keyboard: false,
                    backdrop: 'static',
                });
            });

            take1Btn.on('click', function () {
                $.ajax({
                    method: "POST",
                    url: "https://localhost:8443/SGIFPCapture"
                }).done(function(msg) {
                    var res = JSON.parse(msg);
                    if (res.hasOwnProperty('ErrorCode') && res.hasOwnProperty('BMPBase64') && res.ErrorCode === 0) {
                        fp1 = res;
                        fpImg1.attr('src', 'data:image/bmp;base64,'+res.BMPBase64);
                        fpImg1.removeClass('d-none');
                        submit();
                    } else {
                        alert( "Device not connected" );
                    }
                }).fail(function() {
                    alert( "Device not connected" );
                })
            });

            take2Btn.on('click', function () {
                $.ajax({
                    method: "POST",
                    url: "https://localhost:8443/SGIFPCapture"
                }).done(function(msg) {
                    var res = JSON.parse(msg);
                    if (res.hasOwnProperty('ErrorCode') && res.hasOwnProperty('BMPBase64') && res.ErrorCode === 0) {
                        fp2 = res;
                        fpImg2.attr('src', 'data:image/bmp;base64,'+res.BMPBase64);
                        fpImg2.removeClass('d-none');
                        submit();
                    } else {
                        alert( "Device not connected" );
                    }
                }).fail(function() {
                    alert( "Device not connected" );
                })
            });

            takeAtnBtn.on('click', function () {
                $.ajax({
                    method: "POST",
                    url: "https://localhost:8443/SGIFPCapture"
                }).done(function(msg) {
                    var res = JSON.parse(msg);
                    if (res.hasOwnProperty('ErrorCode') && res.hasOwnProperty('BMPBase64') && res.ErrorCode === 0) {
                        fp3 = res;
                        fpAtnImg.attr('src', 'data:image/bmp;base64,'+res.BMPBase64);
                        fpAtnImg.removeClass('d-none');

                        mgsAtnP.removeClass('d-none')
                        mgsAtnP.addClass('d-block')
                        mgsAtnP.text('Fingerprint attendance done');

                    } else {
                        alert( "Device not connected" );
                    }
                }).fail(function() {
                    alert( "Device not connected" );
                })
            });

            resetBtn.on('click', function () {
                fp1 = null;
                fp2 = null;
                fpImg1.addClass('d-none');
                fpImg1.attr('src', '');
                fpImg2.addClass('d-none');
                fpImg2.attr('src', '');
                mgsEl.addClass('d-none')
                mgsEl.removeClass('d-block')
            });
        });

        function submit() {
            var mgsEl = $('#mgsP');
            mgsEl.addClass('d-none')
            mgsEl.removeClass('d-block')
            if (fp1 && fp2) {
                $.ajax({
                    method: "POST",
                    url: "{{ route('teacher.attendance.create__enroll', ['id' => \request()->segment(3)]) }}",
                    data: {fp1: fp1, fp2: fp2}
                }).done(function(msg) {
                    mgsEl.removeClass('d-none')
                    mgsEl.addClass('d-block')
                    mgsEl.text('Fingerprint enrollment done');
                    $('#hasFp').text('Yes');
                }).fail(function() {
                    mgsEl.removeClass('d-none')
                    mgsEl.addClass('d-block')
                    mgsEl.text('Server Error');
                })
            }
        }
    </script>
@endpush
