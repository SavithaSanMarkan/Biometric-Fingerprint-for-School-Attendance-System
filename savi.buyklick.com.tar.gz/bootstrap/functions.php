<?php

if(!function_exists('getListItems'))
{
    /**
     * @param \Illuminate\Http\Request $request
     * @param string $sortBy
     * @param array $mores
     * @return array
     */
    function getListItems(\Illuminate\Http\Request $request, $sortBy = 'name,created_at', $mores = [])
    {
        $validates = [
            'page' => 'nullable|digits_between:1,10',
            'sort' => 'nullable|in:'.$sortBy,
            'type' => 'nullable|in:asc,desc',
            'query' => 'nullable|string|max:50',
            'item' => 'nullable|numeric|min:10|max:100|in:10,20,50,100',
        ];
        if(!empty($mores)) {
            $validates = array_merge($validates, $mores);
        }
        $request->validate($validates);
        $sort = $request->post('sort') ?: 'created_at';
        $type = $request->post('type') ?: 'desc';
        $query = $request->post('query');
        $item = $request->post('item') ?: 10;
        return [$sort, $type, $query, $item];
    }
}
