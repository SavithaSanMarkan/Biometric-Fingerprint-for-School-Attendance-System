<?php

use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return redirect()->route('admin.dashboard.view');
});

Route::get('/dashboard', [App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('dashboard.view');

Route::controller(App\Http\Controllers\Admin\ProfileController::class)
    ->prefix('profile')
    ->group(function () {
        Route::get('/','index')->name('profile.view');
        Route::post('/', 'update')->name('profile.edit');
        Route::patch('/', 'password')->name('profile.edit__password');
    });


Route::prefix('settings')
    ->group(function () {
        Route::controller(App\Http\Controllers\Admin\AppSettingController::class)->group(function () {
            Route::get('/','index')->name('settings_app.view');
            Route::post('/', 'update')->name('settings_app.edit');
            Route::post('/logo', 'logo')->name('settings_app.edit__logo');
        });

        Route::controller(App\Http\Controllers\Admin\FacultyController::class)->group(function () {
            Route::get('/faculties','index')->name('settings_faculty.view');
            Route::post('/faculties', 'getAll')->name('settings_faculty.view__list');
            Route::post('/faculty', 'submit')->name('settings_faculty.create');
            Route::post('/faculty/{id}', 'update')->name('settings_faculty.edit');
            Route::delete('/faculty/{id}', 'delete')->name('settings_faculty.delete');
        });

        Route::controller(App\Http\Controllers\Admin\DepartmentController::class)->group(function () {
            Route::get('/departments','index')->name('settings_department.view');
            Route::post('/departments', 'getAll')->name('settings_department.view__list');
            Route::post('/department', 'submit')->name('settings_department.create');
            Route::post('/department/{id}', 'update')->name('settings_department.edit');
            Route::delete('/department/{id}', 'delete')->name('settings_department.delete');
        });

        Route::controller(App\Http\Controllers\Admin\SubjectController::class)->group(function () {
            Route::get('/subjects','index')->name('settings_subject.view');
            Route::post('/subjects', 'getAll')->name('settings_subject.view__list');
            Route::post('/subject', 'submit')->name('settings_subject.create');
            Route::post('/subject/{id}', 'update')->name('settings_subject.edit');
            Route::delete('/subject/{id}', 'delete')->name('settings_subject.delete');
        });
    });

Route::controller(App\Http\Controllers\Admin\SubjectEnrollmentController::class)->group(function () {
    Route::get('/subject-enrollments','index')->name('subject_enrollment.view');
    Route::post('/subject-enrollments', 'getAll')->name('subject_enrollment.view__list');
    Route::post('/subject-enrollment', 'submit')->name('subject_enrollment.create');
    Route::delete('/subject-enrollment/{id}', 'delete')->name('subject_enrollment.delete');
});

Route::controller(App\Http\Controllers\Admin\SubjectTimeController::class)->group(function () {
    Route::get('/subject-times','index')->name('subject_time.view');
    Route::post('/subject-times', 'getAll')->name('subject_time.view__list');
    Route::post('/subject-time', 'submit')->name('subject_time.create');
    Route::delete('/subject-time/{id}', 'delete')->name('subject_time.delete');
});

Route::controller(App\Http\Controllers\Admin\TeacherController::class)->group(function () {
    Route::get('/teachers','index')->name('teacher.view');
    Route::post('/teachers', 'getAll')->name('teacher.view__list');
    Route::post('/teacher', 'submit')->name('teacher.create');
    Route::post('/teacher/{id}', 'update')->name('teacher.edit');
    Route::delete('/teacher/{id}', 'delete')->name('teacher.delete');
});

Route::controller(App\Http\Controllers\Admin\StudentController::class)->group(function () {
    Route::get('/students','index')->name('student.view');
    Route::post('/students', 'getAll')->name('student.view__list');
    Route::post('/student', 'submit')->name('student.create');
    Route::post('/student/{id}', 'update')->name('student.edit');
    Route::delete('/student/{id}', 'delete')->name('student.delete');
});
