<?php

use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return redirect()->route('teacher.dashboard.view');
});

Route::get('/dashboard', [App\Http\Controllers\Teacher\DashboardController::class, 'index'])->name('dashboard.view');

Route::controller(App\Http\Controllers\Teacher\ProfileController::class)
    ->prefix('profile')
    ->group(function () {
        Route::get('/','index')->name('profile.view');
        Route::post('/', 'update')->name('profile.edit');
        Route::patch('/', 'password')->name('profile.edit__password');
    });

Route::controller(App\Http\Controllers\Teacher\SubjectEnrollmentController::class)->group(function () {
    Route::get('/subject-enrollments','index')->name('subject_enrollment.view');
    Route::post('/subject-enrollments', 'getAll')->name('subject_enrollment.view__list');
    Route::post('/subject-enrollment', 'submit')->name('subject_enrollment.create');
    Route::delete('/subject-enrollment/{id}', 'delete')->name('subject_enrollment.delete');
});

Route::controller(App\Http\Controllers\Teacher\StudentEnrollmentController::class)->group(function () {
    Route::get('/student-enrollments','index')->name('student_enrollment.view');
    Route::post('/student-enrollments', 'getAll')->name('student_enrollment.view__list');
    Route::post('/student-enrollment', 'submit')->name('student_enrollment.create');
    Route::delete('/student-enrollment/{id}', 'delete')->name('student_enrollment.delete');
});

Route::controller(App\Http\Controllers\Teacher\AttendanceController::class)->group(function () {
    Route::get('/attendance/{id}','index')->name('attendance.view');
    Route::post('/attendance/{id}','create')->name('attendance.create');
    Route::post('/attendance/{id}/enroll','enroll')->name('attendance.create__enroll');
});
