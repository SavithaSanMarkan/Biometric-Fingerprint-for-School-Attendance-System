<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('student.dashboard.view');
});

Route::get('/dashboard', [App\Http\Controllers\Student\DashboardController::class, 'index'])->name('dashboard.view');

Route::controller(App\Http\Controllers\Student\ProfileController::class)
    ->prefix('profile')
    ->group(function () {
        Route::get('/','index')->name('profile.view');
        Route::post('/', 'update')->name('profile.edit');
        Route::patch('/', 'password')->name('profile.edit__password');
    });

Route::controller(App\Http\Controllers\Student\EnrollmentController::class)->group(function () {
    Route::get('/enrollments','index')->name('enrollment.view');
    Route::post('/enrollments', 'getAll')->name('enrollment.view__list');
});

Route::controller(App\Http\Controllers\Student\AttendanceController::class)->group(function () {
    Route::get('/attendance/{id}','index')->name('attendance.view');
    Route::post('/attendance/{id}', 'submit')->name('attendance.create');
});
