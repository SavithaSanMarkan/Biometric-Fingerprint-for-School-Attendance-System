<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('subject_enrollments', function (Blueprint $table) {
            $table->mediumIncrements('id');
            $table->unsignedSmallInteger('department_id');
            $table->unsignedSmallInteger('subject_id');
            $table->string('intake', 7);
            $table->unsignedDecimal('credit_hour', 3,1);
            $table->string('remark', 999)->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->unique(['department_id', 'subject_id', 'intake'], 'subject_enrollment_unique');
            $table->foreign('department_id')->on('departments')->references('id');
            $table->foreign('subject_id')->on('subjects')->references('id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('subject_enrollments');
    }
};
