<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('student_enrollments', function (Blueprint $table) {
            $table->mediumIncrements('id');
            $table->unsignedMediumInteger('subject_time_id');
            $table->unsignedMediumInteger('student_id');
            $table->boolean('is_active')->default(true);
            $table->string('remark', 999)->nullable();
            $table->unsignedMediumInteger('enrolled_by');
            $table->timestamps();

            $table->unique(['subject_time_id','student_id','enrolled_by'], 'student_enrollment_unique');
            $table->foreign('subject_time_id')->on('subject_times')->references('id');
            $table->foreign('student_id')->on('students')->references('id');
            $table->foreign('enrolled_by')->on('teachers')->references('id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('student_enrollments');
    }
};
