<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('teacher_enrollments', function (Blueprint $table) {
            $table->mediumIncrements('id');
            $table->unsignedMediumInteger('subject_time_id');
            $table->unsignedMediumInteger('teacher_id');
            $table->boolean('is_active')->default(true);
            $table->string('remark', 999)->nullable();
            $table->timestamps();

            $table->unique(['subject_time_id','teacher_id'], 'teacher_enrollment_unique');
            $table->foreign('subject_time_id')->on('subject_times')->references('id');
            $table->foreign('teacher_id')->on('teachers')->references('id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('teacher_enrollments');
    }
};
