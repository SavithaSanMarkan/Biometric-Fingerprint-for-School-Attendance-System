<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('subject_times', function (Blueprint $table) {
            $table->mediumIncrements('id');
            $table->unsignedMediumInteger('subject_enrollment_id');
            $table->string('timetable');
            $table->timestamps();

            $table->unique(['subject_enrollment_id','timetable'], 'subject_times_unique');
            $table->foreign('subject_enrollment_id')->on('subject_enrollments')->references('id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('subject_times');
    }
};
